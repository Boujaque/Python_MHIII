class Contact:
    def __init__(self):
        pass

    def contact_customer(self):

        print("Contact Customer")
