# from Chapter8_Modules.ecommerce.customer.contact import Contact
# from ecommerce.customer import contact
# from ..customer import contact # not recomended by pep8

print("Sales initialized", __name__)

# contact1 = Contact()

# contact1.contact_customer()


def calc_tax():
    pass


def calc_shipping():

    pass


if __name__ == "__main__":
    print("sales started")
    calc_tax()
